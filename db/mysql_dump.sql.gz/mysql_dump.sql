-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 12/12/2013 às 15h26min
-- Versão do Servidor: 5.5.21
-- Versão do PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `pinc`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunos`
--

CREATE TABLE IF NOT EXISTS `alunos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_projeto` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(60) NOT NULL,
  `data_inicio` datetime DEFAULT NULL,
  `data_fim` datetime DEFAULT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id_projeto` (`id_projeto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=146 ;

--
-- Extraindo dados da tabela `alunos`
--

INSERT INTO `alunos` (`id`, `id_projeto`, `nome`, `email`, `data_inicio`, `data_fim`, `data_cadastro`) VALUES
(144, 75, 'ALUNO TESTE 6', 'TESTE6@TESTE.COM.BR', NULL, NULL, '2013-12-04 17:58:13'),
(145, 75, 'ALUNO TESTE 6', 'TESTE6@TESTE.COM.BR', NULL, NULL, '2013-04-12 19:04:29');

-- --------------------------------------------------------

--
-- Estrutura da tabela `dados_professor`
--

CREATE TABLE IF NOT EXISTS `dados_professor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_projeto` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `id_lattes` varchar(16) NOT NULL,
  `email` varchar(60) NOT NULL,
  `telefone` int(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_projeto` (`id_projeto`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `dados_professor`
--

INSERT INTO `dados_professor` (`id`, `id_projeto`, `nome`, `id_lattes`, `email`, `telefone`) VALUES
(1, 75, 'PROFESSOR TESTE 3', '444444444444444', 'TESTE2@TESTE.COM.BR', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `projetos`
--

CREATE TABLE IF NOT EXISTS `projetos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_projeto` varchar(300) NOT NULL,
  `departamento` varchar(100) NOT NULL,
  `assunto` varchar(200) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `vagas_disponiveis` tinyint(4) NOT NULL,
  `data_inclusao_projeto` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario_criador` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario_criador` (`id_usuario_criador`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

--
-- Extraindo dados da tabela `projetos`
--

INSERT INTO `projetos` (`id`, `nome_projeto`, `departamento`, `assunto`, `descricao`, `vagas_disponiveis`, `data_inclusao_projeto`, `id_usuario_criador`) VALUES
(75, 'PROJETO DE TESTE 222', 'DEPARTAMENTO DE TESTE 1, DEPARTAMENTO DE TESTE 222', 'ASSUNTO TESTE 222', 'LOREM IPSUM DOLOR SIT AMET, CONSECTETUR ADIPISICING ELIT, SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUA. UT ENIM AD MINIM VENIAM, QUIS NOSTRUD EXERCITATION ULLAMCO LABORIS NISI UT ALIQUIP EX EA COMMODO CONSEQUAT. DUIS AUTE IRURE DOLOR IN REPREHENDERIT IN VOLUPTATE VELIT ESSE CILLUM DOLORE EU FUGIAT NULLA PARIATUR. EXCEPTEUR SINT OCCAECAT CUPIDATAT NON PROIDENT, SUNT IN CULPA QUI OFFICIA DESERUNT MOLLIT ANIM ID EST LABORUM.', 2, '2013-11-28 17:56:12', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `system_menu`
--

CREATE TABLE IF NOT EXISTS `system_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `nome_maquina` varchar(150) NOT NULL,
  `ativo` tinyint(4) NOT NULL DEFAULT '0',
  `papel` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Extraindo dados da tabela `system_menu`
--

INSERT INTO `system_menu` (`id`, `nome`, `nome_maquina`, `ativo`, `papel`) VALUES
(1, 'Menu Principal', 'menu_principal', 1, '0'),
(2, 'Menu Professor', 'menu_professor', 1, '2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `system_menu_itens`
--

CREATE TABLE IF NOT EXISTS `system_menu_itens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idMenu` int(11) NOT NULL,
  `idSuperior` int(11) DEFAULT NULL,
  `peso` int(11) NOT NULL DEFAULT '0',
  `nome` varchar(150) NOT NULL,
  `link` varchar(500) NOT NULL,
  `attr` varchar(100) DEFAULT NULL,
  `target` varchar(100) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '0',
  `papel` varchar(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idMenu` (`idMenu`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `system_menu_itens`
--

INSERT INTO `system_menu_itens` (`id`, `idMenu`, `idSuperior`, `peso`, `nome`, `link`, `attr`, `target`, `ativo`, `papel`) VALUES
(1, 1, NULL, 0, 'Inicio', 'index', NULL, NULL, 1, '0'),
(4, 1, NULL, 3, 'Administração', 'admin', NULL, NULL, 1, '2'),
(6, 1, NULL, 50, 'Sair', 'logout', NULL, NULL, 1, '1,2'),
(12, 2, NULL, 1, 'Listar Projetos', 'admin/list/projeto', '{"id":1,"class":"list","style":3,"rel":4}', NULL, 1, '2'),
(13, 2, NULL, 0, 'Novo Projeto', 'admin/add/projeto', '{"id":1,"class":"add","style":3,"rel":4} 	', NULL, 1, '2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `system_page`
--

CREATE TABLE IF NOT EXISTS `system_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(80) NOT NULL,
  `titulo` varchar(80) NOT NULL,
  `perfil` tinyint(4) NOT NULL,
  `ativo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Extraindo dados da tabela `system_page`
--

INSERT INTO `system_page` (`id`, `url`, `titulo`, `perfil`, `ativo`) VALUES
(1, 'index', 'Index', 0, 1),
(6, 'lembrar-senha', 'Reenvio de Senha', 0, 1),
(7, 'nova-senha/', 'Nova Senha', 1, 1),
(8, 'logout', 'Logout', 0, 1),
(9, 'admin', 'Administração', 2, 1),
(17, 'list-projeto', 'Lista de Projetos', 0, 1),
(18, 'admin/list/projeto', 'Lista de Projetos', 2, 1),
(19, 'admin/add/projeto', 'Novo Projeto', 2, 1),
(20, 'admin/edit/projeto', 'Editar Projeto', 2, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cpf` varchar(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(150) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `ultimo_login` date NOT NULL,
  `perfil` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `cpf`, `email`, `senha`, `nome`, `ultimo_login`, `perfil`) VALUES
(2, '00000000000', 'felipemeirelles@tic.ufrj.br', '2b32e78d6deb7868d9c89523ea9ecee11151a446', 'Administrador Geral EEI', '2012-11-26', 2),
(3, '11732673799', 'felipemeirelles@tic.ufrj.br', '2b32e78d6deb7868d9c89523ea9ecee11151a446', 'Felipe Meirelles', '2013-11-22', 2);

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `alunos`
--
ALTER TABLE `alunos`
  ADD CONSTRAINT `alunos_ibfk_1` FOREIGN KEY (`id_projeto`) REFERENCES `projetos` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `dados_professor`
--
ALTER TABLE `dados_professor`
  ADD CONSTRAINT `dados_professor_ibfk_1` FOREIGN KEY (`id_projeto`) REFERENCES `projetos` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `projetos`
--
ALTER TABLE `projetos`
  ADD CONSTRAINT `projetos_ibfk_1` FOREIGN KEY (`id_usuario_criador`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para a tabela `system_menu_itens`
--
ALTER TABLE `system_menu_itens`
  ADD CONSTRAINT `system_menu_itens_ibfk_1` FOREIGN KEY (`idMenu`) REFERENCES `system_menu` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

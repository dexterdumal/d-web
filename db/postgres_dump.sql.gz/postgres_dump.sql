--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

--
-- Name: sha1(bytea); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION sha1(bytea) RETURNS character varying
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN ENCODE(DIGEST($1, 'sha1'), 'hex');
END;
$_$;


ALTER FUNCTION public.sha1(bytea) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alunos; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE alunos (
    id integer NOT NULL,
    id_projeto integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(60) NOT NULL,
    data_inicio timestamp without time zone,
    data_fim timestamp without time zone,
    data_cadastro timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alunos OWNER TO felipe;

--
-- Name: alunos_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE alunos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.alunos_id_seq OWNER TO felipe;

--
-- Name: alunos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE alunos_id_seq OWNED BY alunos.id;


--
-- Name: dados_professor; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE dados_professor (
    id integer NOT NULL,
    id_projeto integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(60) NOT NULL,
    telefone integer,
    id_lattes character varying(16) NOT NULL
);


ALTER TABLE public.dados_professor OWNER TO felipe;

--
-- Name: dados_professor_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE dados_professor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dados_professor_id_seq OWNER TO felipe;

--
-- Name: dados_professor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE dados_professor_id_seq OWNED BY dados_professor.id;


--
-- Name: projetos; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE projetos (
    id integer NOT NULL,
    nome_projeto character varying(300) NOT NULL,
    departamento character varying(100) NOT NULL,
    assunto character varying(200) NOT NULL,
    descricao character varying(500) NOT NULL,
    vagas_disponiveis smallint NOT NULL,
    data_inclusao_projeto timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criador integer NOT NULL
);


ALTER TABLE public.projetos OWNER TO felipe;

--
-- Name: projetos_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE projetos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projetos_id_seq OWNER TO felipe;

--
-- Name: projetos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE projetos_id_seq OWNED BY projetos.id;


--
-- Name: system_menu; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE system_menu (
    id integer NOT NULL,
    nome character varying(150) NOT NULL,
    nome_maquina character varying(150) NOT NULL,
    ativo smallint NOT NULL,
    papel character varying(10) NOT NULL
);


ALTER TABLE public.system_menu OWNER TO felipe;

--
-- Name: system_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE system_menu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_menu_id_seq OWNER TO felipe;

--
-- Name: system_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE system_menu_id_seq OWNED BY system_menu.id;


--
-- Name: system_menu_itens; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE system_menu_itens (
    id integer NOT NULL,
    id_menu integer NOT NULL,
    id_superior integer,
    peso smallint NOT NULL,
    nome character varying(150) NOT NULL,
    link character varying(300) NOT NULL,
    attr character varying(100) DEFAULT NULL::character varying,
    target character varying(100) DEFAULT NULL::character varying,
    ativo boolean NOT NULL,
    papel character varying(10) NOT NULL
);


ALTER TABLE public.system_menu_itens OWNER TO felipe;

--
-- Name: system_menu_itens_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE system_menu_itens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_menu_itens_id_seq OWNER TO felipe;

--
-- Name: system_menu_itens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE system_menu_itens_id_seq OWNED BY system_menu_itens.id;


--
-- Name: system_page; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE system_page (
    id integer NOT NULL,
    url character varying NOT NULL,
    titulo character varying NOT NULL,
    perfil smallint NOT NULL,
    ativo boolean NOT NULL
);


ALTER TABLE public.system_page OWNER TO felipe;

--
-- Name: system_page_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE system_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_page_id_seq OWNER TO felipe;

--
-- Name: system_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE system_page_id_seq OWNED BY system_page.id;


--
-- Name: system_user; Type: TABLE; Schema: public; Owner: felipe; Tablespace: 
--

CREATE TABLE system_user (
    id integer NOT NULL,
    login character varying(100) NOT NULL,
    senha character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    nome character varying(100) NOT NULL,
    ultimo_login timestamp without time zone NOT NULL,
    perfil smallint NOT NULL
);


ALTER TABLE public.system_user OWNER TO felipe;

--
-- Name: system_user_id_seq; Type: SEQUENCE; Schema: public; Owner: felipe
--

CREATE SEQUENCE system_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_user_id_seq OWNER TO felipe;

--
-- Name: system_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: felipe
--

ALTER SEQUENCE system_user_id_seq OWNED BY system_user.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY alunos ALTER COLUMN id SET DEFAULT nextval('alunos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY dados_professor ALTER COLUMN id SET DEFAULT nextval('dados_professor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY projetos ALTER COLUMN id SET DEFAULT nextval('projetos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY system_menu ALTER COLUMN id SET DEFAULT nextval('system_menu_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY system_menu_itens ALTER COLUMN id SET DEFAULT nextval('system_menu_itens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY system_page ALTER COLUMN id SET DEFAULT nextval('system_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: felipe
--

ALTER TABLE ONLY system_user ALTER COLUMN id SET DEFAULT nextval('system_user_id_seq'::regclass);


--
-- Data for Name: alunos; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO alunos VALUES (1, 2, 'felipe', 'a@b.com', '2012-05-10 11:52:25', NULL, '2013-12-03 11:55:49.391918');
INSERT INTO alunos VALUES (2, 1, 'ALUNO TESTE 6', 'TESTE6@TESTE.COM.BR', NULL, NULL, '2013-12-12 13:19:21.868423');
INSERT INTO alunos VALUES (3, 1, 'ALUNO TESTE 6', 'TESTE6@TESTE.COM.BR', NULL, NULL, '2013-12-12 13:19:37.24567');


--
-- Name: alunos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('alunos_id_seq', 3, true);


--
-- Data for Name: dados_professor; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO dados_professor VALUES (1, 1, 'PROFESSOR TESTE 3', 'TESTE2@TESTE.COM.BR', NULL, '444444444444444');


--
-- Name: dados_professor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('dados_professor_id_seq', 1, true);


--
-- Data for Name: projetos; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO projetos VALUES (1, 'PROJETO DE TESTE 222', 'DEPARTAMENTO DE TESTE 1, DEPARTAMENTO DE TESTE 222', 'ASSUNTO TESTE 222', 'LOREM IPSUM DOLOR SIT AMET, CONSECTETUR ADIPISICING ELIT, SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUA. UT ENIM AD MINIM VENIAM, QUIS NOSTRUD EXERCITATION ULLAMCO LABORIS NISI UT ALIQUIP EX EA COMMODO CONSEQUAT. DUIS AUTE IRURE DOLOR IN REPREHENDERIT IN VOLUPTATE VELIT ESSE CILLUM DOLORE EU FUGIAT NULLA PARIATUR. EXCEPTEUR SINT OCCAECAT CUPIDATAT NON PROIDENT, SUNT IN CULPA QUI OFFICIA DESERUNT MOLLIT ANIM ID EST LABORUM.', 2, '2013-12-12 13:17:41.564069', 2);


--
-- Name: projetos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('projetos_id_seq', 1, true);


--
-- Data for Name: system_menu; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO system_menu VALUES (1, 'Menu Principal', 'menu_principal', 1, '0');
INSERT INTO system_menu VALUES (2, 'Menu Professor', 'menu_professor', 1, '2');


--
-- Name: system_menu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('system_menu_id_seq', 2, true);


--
-- Data for Name: system_menu_itens; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO system_menu_itens VALUES (1, 1, NULL, 0, 'Inicio', 'index', NULL, NULL, true, '0');
INSERT INTO system_menu_itens VALUES (2, 1, NULL, 3, 'Administração', 'admin', NULL, NULL, true, '2');
INSERT INTO system_menu_itens VALUES (3, 1, NULL, 50, 'Sair', 'logout', NULL, NULL, true, '1,2');
INSERT INTO system_menu_itens VALUES (4, 2, NULL, 1, 'Listar Projetos', 'admin/list/projeto', '{"id":1,"class":"list","style":3,"rel":4}', NULL, true, '2');
INSERT INTO system_menu_itens VALUES (5, 2, NULL, 0, 'Novo Projeto', 'admin/add/projeto', '{"id":1,"class":"add","style":3,"rel":4}', NULL, true, '2');


--
-- Name: system_menu_itens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('system_menu_itens_id_seq', 5, true);


--
-- Data for Name: system_page; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO system_page VALUES (1, 'index', 'Index', 0, true);
INSERT INTO system_page VALUES (2, 'lembrar-senha', 'Reenvio de Senha', 0, true);
INSERT INTO system_page VALUES (3, 'nova-senha/', 'Nova Senha', 1, true);
INSERT INTO system_page VALUES (4, 'logout', 'Logout', 0, true);
INSERT INTO system_page VALUES (5, 'admin', 'Administração', 2, true);
INSERT INTO system_page VALUES (6, 'list-projeto', 'Lista de Projetos', 0, true);
INSERT INTO system_page VALUES (7, 'admin/list/projeto', 'Lista de Projetos', 2, true);
INSERT INTO system_page VALUES (8, 'admin/add/projeto', 'Novo Projeto', 2, true);
INSERT INTO system_page VALUES (9, 'admin/edit/projeto', 'Editar Projeto', 2, true);


--
-- Name: system_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('system_page_id_seq', 9, true);


--
-- Data for Name: system_user; Type: TABLE DATA; Schema: public; Owner: felipe
--

INSERT INTO system_user VALUES (2, '11732673799', '2b32e78d6deb7868d9c89523ea9ecee11151a446', 'felipemeirelles@tic.ufrj.br 	', 'Felipe Meirelles', '2013-11-22 00:00:00', 2);
INSERT INTO system_user VALUES (1, '00000000000', '2b32e78d6deb7868d9c89523ea9ecee11151a446', 'dexter.meireles@gmail.com', 'Administrador Geral EEI 	', '2013-12-11 10:30:38.905029', 1);


--
-- Name: system_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: felipe
--

SELECT pg_catalog.setval('system_user_id_seq', 2, true);


--
-- Name: alunos_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY alunos
    ADD CONSTRAINT alunos_pkey PRIMARY KEY (id);


--
-- Name: dados_professor_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY dados_professor
    ADD CONSTRAINT dados_professor_pkey PRIMARY KEY (id);


--
-- Name: projetos_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY projetos
    ADD CONSTRAINT projetos_pkey PRIMARY KEY (id);


--
-- Name: system_menu_itens_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY system_menu_itens
    ADD CONSTRAINT system_menu_itens_pkey PRIMARY KEY (id);


--
-- Name: system_menu_nome_maquina_key; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY system_menu
    ADD CONSTRAINT system_menu_nome_maquina_key UNIQUE (nome_maquina);


--
-- Name: system_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY system_menu
    ADD CONSTRAINT system_menu_pkey PRIMARY KEY (id);


--
-- Name: system_page_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY system_page
    ADD CONSTRAINT system_page_pkey PRIMARY KEY (id);


--
-- Name: system_user_pkey; Type: CONSTRAINT; Schema: public; Owner: felipe; Tablespace: 
--

ALTER TABLE ONLY system_user
    ADD CONSTRAINT system_user_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

